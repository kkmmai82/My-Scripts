N7R - خطوات الحصول على ملف IPA من ويندوز
1) أنشئ مستودع على GitHub وارفع كل محتويات هذا المجلد (بما فيه .github).
2) من تبويب Actions شغّل Build N7R IPA.
3) بعد انتهائه نزّل N7R-ipa من Artifacts.
4) وقّعه وثبّته بآيفونك عبر Sideloadly أو AltStore (ويندوز) بآيديك.
