import 'package:flutter/material.dart';
import 'package:flutter_localizations/flutter_localizations.dart';

void main() => runApp(const N7R());

const kGrad = LinearGradient(
  begin: Alignment.topRight, end: Alignment.bottomLeft,
  colors: [Color(0xFFFF4FA3), Color(0xFFB44CFF), Color(0xFF6A2CFF)],
);

class N7R extends StatelessWidget {
  const N7R({super.key});
  @override
  Widget build(BuildContext c) => MaterialApp(
        title: 'N7R',
        debugShowCheckedModeBanner: false,
        locale: const Locale('ar'),
        supportedLocales: const [Locale('ar')],
        localizationsDelegates: const [
          GlobalMaterialLocalizations.delegate,
          GlobalWidgetsLocalizations.delegate,
          GlobalCupertinoLocalizations.delegate,
        ],
        theme: ThemeData(
          useMaterial3: true,
          brightness: Brightness.dark,
          scaffoldBackgroundColor: const Color(0xFF14061F),
          colorSchemeSeed: const Color(0xFFB44CFF),
        ),
        home: const Splash(),
      );
}

class Splash extends StatefulWidget {
  const Splash({super.key});
  @override
  State<Splash> createState() => _SplashState();
}

class _SplashState extends State<Splash> {
  @override
  void initState() {
    super.initState();
    Future.delayed(const Duration(milliseconds: 1800), () {
      if (mounted) {
        Navigator.pushReplacement(context,
            PageRouteBuilder(pageBuilder: (_, a, __) => FadeTransition(opacity: a, child: const Login())));
      }
    });
  }

  @override
  Widget build(BuildContext c) => Scaffold(
        body: Container(
          decoration: const BoxDecoration(gradient: kGrad),
          child: Center(
            child: TweenAnimationBuilder<double>(
              tween: Tween(begin: 0.4, end: 1),
              duration: const Duration(milliseconds: 1200),
              curve: Curves.elasticOut,
              builder: (_, v, ch) => Transform.scale(scale: v, child: ch),
              child: const Text('N7R',
                  style: TextStyle(fontSize: 72, fontWeight: FontWeight.w900, letterSpacing: 6, color: Colors.white)),
            ),
          ),
        ),
      );
}

class Glass extends StatelessWidget {
  final Widget child;
  final EdgeInsets pad;
  const Glass({super.key, required this.child, this.pad = const EdgeInsets.all(16)});
  @override
  Widget build(BuildContext c) => Container(
        padding: pad,
        decoration: BoxDecoration(
          color: Colors.white.withOpacity(0.08),
          borderRadius: BorderRadius.circular(24),
          border: Border.all(color: Colors.white.withOpacity(0.15)),
        ),
        child: child,
      );
}

class GradButton extends StatelessWidget {
  final String text;
  final VoidCallback onTap;
  const GradButton(this.text, this.onTap, {super.key});
  @override
  Widget build(BuildContext c) => GestureDetector(
        onTap: onTap,
        child: Container(
          height: 54,
          alignment: Alignment.center,
          decoration: BoxDecoration(
            gradient: kGrad,
            borderRadius: BorderRadius.circular(18),
            boxShadow: [BoxShadow(color: const Color(0xFFB44CFF).withOpacity(0.5), blurRadius: 24, offset: const Offset(0, 8))],
          ),
          child: Text(text, style: const TextStyle(fontSize: 18, fontWeight: FontWeight.bold, color: Colors.white)),
        ),
      );
}

class Login extends StatelessWidget {
  const Login({super.key});
  @override
  Widget build(BuildContext c) {
    InputDecoration d(String h, IconData i) => InputDecoration(
          hintText: h, prefixIcon: Icon(i), filled: true,
          fillColor: Colors.white.withOpacity(0.08),
          border: OutlineInputBorder(borderRadius: BorderRadius.circular(16), borderSide: BorderSide.none),
        );
    return Scaffold(
      body: Stack(children: [
        Positioned(top: -80, right: -60, child: _orb(260, const Color(0xFFFF4FA3))),
        Positioned(bottom: -100, left: -80, child: _orb(300, const Color(0xFF6A2CFF))),
        SafeArea(
          child: Center(
            child: SingleChildScrollView(
              padding: const EdgeInsets.all(24),
              child: Glass(
                pad: const EdgeInsets.all(24),
                child: Column(mainAxisSize: MainAxisSize.min, children: [
                  ShaderMask(
                    shaderCallback: (r) => kGrad.createShader(r),
                    child: const Text('N7R', style: TextStyle(fontSize: 56, fontWeight: FontWeight.w900, color: Colors.white)),
                  ),
                  const SizedBox(height: 6),
                  const Text('شاركهم عالمك ✨', style: TextStyle(color: Colors.white70)),
                  const SizedBox(height: 24),
                  TextField(decoration: d('اسم المستخدم', Icons.person_outline)),
                  const SizedBox(height: 12),
                  TextField(obscureText: true, decoration: d('كلمة المرور', Icons.lock_outline)),
                  const SizedBox(height: 20),
                  GradButton('تسجيل الدخول', () => Navigator.pushReplacement(c, MaterialPageRoute(builder: (_) => const Home()))),
                  const SizedBox(height: 12),
                  TextButton(onPressed: () {}, child: const Text('ما عندك حساب؟ سجّل الآن')),
                ]),
              ),
            ),
          ),
        ),
      ]),
    );
  }

  Widget _orb(double s, Color col) => Container(
        width: s, height: s,
        decoration: BoxDecoration(shape: BoxShape.circle, gradient: RadialGradient(colors: [col.withOpacity(0.7), Colors.transparent])),
      );
}

class Post {
  final String user, text;
  int likes;
  bool liked = false;
  final List<String> comments = [];
  Post(this.user, this.text, this.likes);
}

class Home extends StatefulWidget {
  const Home({super.key});
  @override
  State<Home> createState() => _HomeState();
}

class _HomeState extends State<Home> {
  int tab = 0;
  final posts = [
    Post('لمى', 'صباح الخير يا عالم 🌸 يوم جديد وطاقة جديدة', 128),
    Post('فهد', 'أجمل غروب شفته اليوم 🌅', 342),
    Post('ريم', 'أول منشور لي على N7R 💜', 56),
  ];

  void compose() {
    final ctl = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: const Color(0xFF1E0A30),
      shape: const RoundedRectangleBorder(borderRadius: BorderRadius.vertical(top: Radius.circular(28))),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          TextField(controller: ctl, maxLines: 4, autofocus: true,
              decoration: const InputDecoration(hintText: 'شو في بالك؟', border: InputBorder.none)),
          GradButton('نشر', () {
            if (ctl.text.trim().isNotEmpty) setState(() => posts.insert(0, Post('أنا', ctl.text.trim(), 0)));
            Navigator.pop(context);
          }),
        ]),
      ),
    );
  }

  @override
  Widget build(BuildContext c) {
    final pages = [feed(), const Center(child: Text('استكشاف 🔍')), const Center(child: Text('الرسائل 💬')), profile()];
    return Scaffold(
      extendBody: true,
      appBar: AppBar(
        backgroundColor: Colors.transparent,
        title: ShaderMask(
          shaderCallback: (r) => kGrad.createShader(r),
          child: const Text('N7R', style: TextStyle(fontWeight: FontWeight.w900, fontSize: 30, color: Colors.white)),
        ),
        actions: [IconButton(onPressed: () {}, icon: const Icon(Icons.notifications_none))],
      ),
      body: pages[tab],
      floatingActionButton: GestureDetector(
        onTap: compose,
        child: Container(
          width: 62, height: 62,
          decoration: BoxDecoration(gradient: kGrad, shape: BoxShape.circle,
              boxShadow: [BoxShadow(color: const Color(0xFFFF4FA3).withOpacity(0.6), blurRadius: 22)]),
          child: const Icon(Icons.add, size: 32, color: Colors.white),
        ),
      ),
      floatingActionButtonLocation: FloatingActionButtonLocation.centerDocked,
      bottomNavigationBar: BottomAppBar(
        color: const Color(0xFF1E0A30), shape: const CircularNotchedRectangle(), notchMargin: 8,
        child: Row(mainAxisAlignment: MainAxisAlignment.spaceAround, children: [
          _nav(Icons.home_rounded, 0), _nav(Icons.search_rounded, 1),
          const SizedBox(width: 40),
          _nav(Icons.chat_bubble_rounded, 2), _nav(Icons.person_rounded, 3),
        ]),
      ),
    );
  }

  Widget _nav(IconData i, int n) => IconButton(
        onPressed: () => setState(() => tab = n),
        icon: Icon(i, color: tab == n ? const Color(0xFFFF4FA3) : Colors.white54, size: 28),
      );

  Widget feed() => Column(children: [
        SizedBox(
          height: 96,
          child: ListView.builder(
            scrollDirection: Axis.horizontal, padding: const EdgeInsets.symmetric(horizontal: 12),
            itemCount: 8,
            itemBuilder: (_, i) => Padding(
              padding: const EdgeInsets.all(6),
              child: Container(
                padding: const EdgeInsets.all(3),
                decoration: const BoxDecoration(gradient: kGrad, shape: BoxShape.circle),
                child: CircleAvatar(radius: 32, backgroundColor: const Color(0xFF14061F),
                    child: Text(i == 0 ? '+' : '${i}', style: const TextStyle(fontSize: 20))),
              ),
            ),
          ),
        ),
        Expanded(
          child: ListView.builder(
            padding: const EdgeInsets.fromLTRB(16, 0, 16, 110),
            itemCount: posts.length,
            itemBuilder: (_, i) => card(posts[i]),
          ),
        ),
      ]);

  Widget card(Post p) => Padding(
        padding: const EdgeInsets.only(bottom: 14),
        child: Glass(
          child: Column(crossAxisAlignment: CrossAxisAlignment.start, children: [
            Row(children: [
              Container(
                padding: const EdgeInsets.all(2),
                decoration: const BoxDecoration(gradient: kGrad, shape: BoxShape.circle),
                child: CircleAvatar(backgroundColor: const Color(0xFF14061F), child: Text(p.user[0])),
              ),
              const SizedBox(width: 10),
              Text(p.user, style: const TextStyle(fontWeight: FontWeight.bold, fontSize: 16)),
              const Spacer(),
              const Icon(Icons.more_horiz, color: Colors.white54),
            ]),
            const SizedBox(height: 12),
            Text(p.text, style: const TextStyle(fontSize: 17, height: 1.5)),
            const SizedBox(height: 12),
            Row(children: [
              IconButton(
                onPressed: () => setState(() { p.liked = !p.liked; p.likes += p.liked ? 1 : -1; }),
                icon: Icon(p.liked ? Icons.favorite : Icons.favorite_border,
                    color: p.liked ? const Color(0xFFFF4FA3) : Colors.white70),
              ),
              Text('${p.likes}'),
              const SizedBox(width: 12),
              IconButton(onPressed: () => comment(p), icon: const Icon(Icons.mode_comment_outlined, color: Colors.white70)),
              Text('${p.comments.length}'),
              const Spacer(),
              const Icon(Icons.share_outlined, color: Colors.white70),
            ]),
          ]),
        ),
      );

  void comment(Post p) {
    final ctl = TextEditingController();
    showModalBottomSheet(
      context: context, isScrollControlled: true, backgroundColor: const Color(0xFF1E0A30),
      builder: (_) => Padding(
        padding: EdgeInsets.fromLTRB(20, 20, 20, MediaQuery.of(context).viewInsets.bottom + 20),
        child: Column(mainAxisSize: MainAxisSize.min, children: [
          ...p.comments.map((t) => ListTile(leading: const Icon(Icons.account_circle), title: Text(t))),
          TextField(controller: ctl, decoration: const InputDecoration(hintText: 'اكتب تعليقك...')),
          const SizedBox(height: 12),
          GradButton('إرسال', () {
            if (ctl.text.trim().isNotEmpty) setState(() => p.comments.add(ctl.text.trim()));
            Navigator.pop(context);
          }),
        ]),
      ),
    );
  }

  Widget profile() => ListView(padding: const EdgeInsets.all(20), children: [
        Container(
          height: 170,
          decoration: BoxDecoration(gradient: kGrad, borderRadius: BorderRadius.circular(28)),
          alignment: Alignment.center,
          child: const CircleAvatar(radius: 46, backgroundColor: Color(0xFF14061F), child: Text('أنا', style: TextStyle(fontSize: 26))),
        ),
        const SizedBox(height: 16),
        const Center(child: Text('@n7r_user', style: TextStyle(fontSize: 20, fontWeight: FontWeight.bold))),
        const SizedBox(height: 16),
        Row(mainAxisAlignment: MainAxisAlignment.spaceEvenly, children: const [
          _Stat('المنشورات', '12'), _Stat('المتابعين', '1.2K'), _Stat('يتابع', '340'),
        ]),
      ]);
}

class _Stat extends StatelessWidget {
  final String l, v;
  const _Stat(this.l, this.v);
  @override
  Widget build(BuildContext c) => Glass(
        pad: const EdgeInsets.symmetric(horizontal: 18, vertical: 12),
        child: Column(children: [Text(v, style: const TextStyle(fontSize: 20, fontWeight: FontWeight.bold)), Text(l, style: const TextStyle(color: Colors.white60))]),
      );
}
